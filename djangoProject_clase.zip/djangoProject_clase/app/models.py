from django.db import models
from django.utils import timezone


class Book(models.Model):
    # attributes
    isbn = models.CharField(max_length=40)
    title = models.CharField(max_length=150)
    year = models.IntegerField(default=0)
    published = models.BooleanField(default=False)
    author = models.CharField(null=True, max_length=100)

    class Meta:
        db_table = "books"

    def __str__(self):
        return self.isbn + " - " + self.title


class Author(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField(null=False, default="support@library.com")
    num_books = models.IntegerField(default=1)
    creation_date = models.DateTimeField(default=timezone.now)
    married = models.BooleanField(default=False)
    salary = models.FloatField(default=0)

    # FIX objects error with this:
    # objects = models.Manager()

    class Meta:
        db_table = "authors"

    def __str__(self):
        return self.first_name + " - " + self.last_name
