from django.urls import path
from . import views

urlpatterns = [
    path('hello/', views.hello),
    path('hello2/', views.hello2),
    path('books/', views.book_list),
    path('authors/', views.author_list),

    # CRUD books
    path('books/<int:id>/load', views.load_book, name="book_load"),
    path('books/save', views.save_book),
    path('books/<str:isbn>/filter', views.filter_book),
    path('books/<int:id>/get', views.get_book, name="book_view"),
    path('books/<int:pk>/delete', views.delete_book, name='book_delete'),
    path('books/<int:year>/delete/all', views.delete_books),


    # CRUD authors

]
