from django.http import HttpResponse, HttpResponseNotFound, HttpResponseRedirect
from django.shortcuts import render
from .models import Book, Author
from django.utils import timezone

def hello(request):
    data = {
        "message": "Hello world!"
    }
    return render(request, "hello1.html", context=data)


def hello2(request):
    return render(request, "hello2.html")


def book_list(request):
    data = {
        "books": Book.objects.all(),  # recupera libros de db,
        "notification": "Listado de libros",
        "admin": False
    }
    return render(request, "books/book-list.html", context=data)


def author_list(request):
    data = {
        "authors": Author.objects.all()
    }
    return render(request, "authors/author-list.html", context=data)

# *************************** CRUD Books *******************


def load_book(request, id):
# Carga los datos a actualizar en el formulario
    data = {
        "book": Book.objects.get(id=id)
    }
    return render(request, "books/book-edit.html", context=data)


def save_book(request):
# Guarda los datos del formulario en base de datos
    if request.method == "GET":
        return render(request, "books/book-edit.html")

    # Crear un nuevo libro
    if not request.POST.get("id"):
        book = Book.objects.create(
            isbn=request.POST.get("isbn"),
            title=request.POST.get("title"),
            year=int(request.POST.get("year")),
            published=bool(request.POST.get("published")),
            author=request.POST.get("author"))
        return HttpResponseRedirect("/books/{}/get".format(book.id))

    # Editar un libro existente
    id_book = int(request.POST.get("id"))
    book = Book.objects.get(id=id_book)

    book.isbn = request.POST.get("isbn")
    book.title = request.POST.get("title")
    book.year = int(request.POST.get("year"))
    book.published = bool(request.POST.get("published"))
    book.author = request.POST.get("author")

    book.save()
    return HttpResponseRedirect("/books/{}/get".format(id_book))


def filter_book(request, isbn):
    print(isbn)
    result = Book.objects.filter(isbn=isbn)
    print(result)
    return HttpResponse(result)


def get_book(request, id):
    data = {
        "book": Book.objects.get(id=id)
    }
    return render(request, "books/book-view.html", context=data)


def delete_book(request, pk):
    try:
        book1 = Book.objects.get(pk=pk)
        book1.delete()
        return HttpResponseRedirect("/books")
    except Book.DoesNotExist:
        return HttpResponseNotFound("Libro no encontrado")


def delete_books(request, year):
    books = Book.objects.filter(year=year)
    result = books.delete()
    return HttpResponse("{} libro/s borrado/s correctamente.".format(result[0]))










