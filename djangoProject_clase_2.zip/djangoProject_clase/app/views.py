from django.http import HttpResponse, HttpResponseNotFound, HttpResponseRedirect
from django.shortcuts import render
from .models import Book, Author, Direction
from django.utils import timezone


# *************************** CRUD Books *******************
def book_list(request):
    data = {
        "books": Book.objects.all(),  # recupera libros de db,
        "notification": "Listado de libros",
        "admin": False
    }
    return render(request, "books/book-list.html", context=data)


def book_load(request, id):
    data = {
        "book": Book.objects.get(id=id)
    }
    return render(request, "books/book-edit.html", context=data)


def book_save(request):
    if request.method == "GET":
        return render(request, "books/book-edit.html")

    # Crear un nuevo libro
    if not request.POST.get("id"):
        book = Book.objects.create(
            isbn=request.POST.get("isbn"),
            title=request.POST.get("title"),
            year=int(request.POST.get("year")),
            published=bool(request.POST.get("published")),
            author=request.POST.get("author"))
        return HttpResponseRedirect("/books/{}/view".format(book.id))

    # Editar un libro existente
    id_book = int(request.POST.get("id"))
    book = Book.objects.get(id=id_book)

    book.isbn = request.POST.get("isbn")
    book.title = request.POST.get("title")
    book.year = int(request.POST.get("year"))
    book.published = bool(request.POST.get("published"))
    book.author = request.POST.get("author")

    book.save()
    return HttpResponseRedirect("/books/{}/view".format(id_book))


def book_filter(request, isbn):
    print(isbn)
    result = Book.objects.filter(isbn=isbn)
    print(result)
    return HttpResponse(result)


def book_view(request, id):
    data = {
        "book": Book.objects.get(id=id)
    }
    return render(request, "books/book-view.html", context=data)


def book_delete(request, pk):
    try:
        book1 = Book.objects.get(pk=pk)
        book1.delete()
        return HttpResponseRedirect("/books")
    except Book.DoesNotExist:
        return HttpResponseNotFound("Libro no encontrado")


def book_delete_by_year(request, year):
    books = Book.objects.filter(year=year)
    result = books.delete()
    return HttpResponse("{} libro/s borrado/s correctamente.".format(result[0]))


# *************************** CRUD Authors *******************

def author_list(request):
    data = {
        "authors": Author.objects.all()
    }
    return render(request, "authors/author-list.html", context=data)


def author_view(request, id):
    data = {
        "author": Author.objects.get(id=id)
    }
    return render(request, "authors/author-view.html", context=data)


def author_delete(request, pk):
    try:
        author = Author.objects.get(pk=pk)
        author.delete()
        return HttpResponseRedirect("/authors")
    except Author.DoesNotExist:
        data = {
            "error": "Autor no encontrado"
        }
        return render(request, "layout/notfound-404.html", context=data)


def author_new(request):
    data = {
        "directions": Direction.objects.all()
    }
    return render(request, "authors/author-edit.html", context=data)


def author_load(request, id):
    data = {
        "author": Author.objects.get(id=id),
        "directions": Direction.objects.filter(author__isnull=True)
    }
    return render(request, "authors/author-edit.html", context=data)


def author_save(request):
    creation = not request.POST.get("id")

    # Extraer la dirección del selector HTML: puede ser None o un id de dirección
    direction_id_str = request.POST.get("direction_id")
    direction_id = int(direction_id_str) if direction_id_str else None

    if creation:

        author = Author.objects.create(
            first_name=request.POST.get("first_name"),
            last_name=request.POST.get("last_name"),
            email=request.POST.get("email"),
            num_books=int(request.POST.get("num_books")),
            creation_date=timezone.now(),
            married=bool(request.POST.get("married")),
            salary=float(request.POST.get("salary")),
            direction_id=direction_id  # Se asocia la dirección
        )

    else:
        id_author = int(request.POST.get("id"))
        author = Author.objects.get(id=id_author)
        author.first_name = request.POST.get("first_name")
        author.last_name = request.POST.get("last_name")
        author.email = request.POST.get("email")
        author.num_books = int(request.POST.get("num_books"))
        author.married = bool(request.POST.get("married"))
        author.salary = float(request.POST.get("salary"))
        author.direction_id = direction_id  # Se asocia la dirección
        author.save()

    return HttpResponseRedirect("/authors/{}/view".format(author.id))



